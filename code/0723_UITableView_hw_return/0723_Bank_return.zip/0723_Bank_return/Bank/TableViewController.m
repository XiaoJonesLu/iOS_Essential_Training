//
//  TableViewController.m
//  Bank
//
//  Created by Xiao on 7/22/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()

@end

@implementation TableViewController

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Account *account = self.allAccounts[indexPath.row];
    cell.textLabel.text = account.username;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"余额: %li", (long)account.balance];
    return cell;
}

@end
