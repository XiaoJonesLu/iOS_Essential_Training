//
//  TableViewController.h
//  Bank
//
//  Created by Xiao on 7/22/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Account.h"
@interface TableViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong) NSMutableArray *allAccounts;
@end
