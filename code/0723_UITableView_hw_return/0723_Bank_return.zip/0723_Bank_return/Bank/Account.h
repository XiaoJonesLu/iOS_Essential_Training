//
//  Account.h
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Account : NSObject

/** 账户名
 */
@property (nonatomic, strong) NSString *username;

/** 密码
 */
@property (nonatomic, strong) NSString *password;

/** 账户余额
 */
@property (nonatomic, assign) NSInteger balance;

/**
 User attempts to withdraw money. If balance is higher than the amount,
 reduces the amount and return YES. Otherwise, do not allow withdraw, 
 and return NO.
 
 用户尝试取款。如果余额大于取款额度，取款成功，从balance中扣取相应数额，返回YES。否则取款失败，返回NO。
 
 @param amount Amount to withdraw. 取款数额。
 */
- (BOOL) withdraw: (NSInteger) amount;

/**
 User attempts to save money. The amount is added to the balance property.
 
 用户存款。在balance中添加相应数额。
 
 @param amount Amount to save. 存款数额。
 */
- (void) save: (NSInteger) amount;

@end
