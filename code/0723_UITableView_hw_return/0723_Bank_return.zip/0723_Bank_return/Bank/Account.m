//
//  Account.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "Account.h"

@implementation Account

- (BOOL) withdraw: (NSInteger) amount {
    // 打印账户名及余额
    NSLog(@"The name of the account is %@", self.username);
    NSLog(@"The balance of the account is %li", self.balance);
    
    // 如果账户余额大于取钱数额，取钱成功
    if (self.balance >= amount) {
        self.balance = self.balance - amount;
        
        // 打印取款额度，以及取款后账户余额
        NSLog(@"User withdrew %li, remaining balance: %li", amount, self.balance);
        
        return YES;
    } else {
        
        // 余额不足，取款失败
        NSLog(@"Withdraw failed!");
        
        return NO;
    }
}

- (void) save: (NSInteger) amount {
    // 打印账户名及余额
    NSLog(@"The name of the account is %@", self.username);
    NSLog(@"The balance of the account is %li", self.balance);
    
    // 存款
    self.balance = self.balance + amount;
    
    // 打印存款余额，以及剩余余额
    NSLog(@"User saved %li, remaining balance: %li", amount, self.balance);
}

@end
