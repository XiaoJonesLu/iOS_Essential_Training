//
//  SaveViewController.m
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "SaveViewController.h"

@interface SaveViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end

@implementation SaveViewController

// 用户输入了存款额度，按下Okay键
- (IBAction)didTapOkay:(id)sender {
    NSString *amount = self.textField.text;
    
    // 将字符转化为数字
    NSInteger integerAmount = [amount integerValue];
    
    // 调用存钱方法
    [self.selectedAccount save:integerAmount];
    
    // 返回WelcomeViewController
    [self performSegueWithIdentifier:@"didFinishWithdraw" sender:self];
}

@end
