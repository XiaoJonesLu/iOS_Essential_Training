//
//  ViewController.m
//  UITableViewDemo
//
//  Created by Xiao on 7/22/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) NSArray *data;
@property (nonatomic, strong) NSArray *section1Data;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSArray *data = @[@"Jan", @"Feb", @"March", @"nbr"];
    self.data = data;
    
    NSArray *section2 = @[@"Mon", @"Tue", @"Wed", @"Thurs"];
    self.section1Data = section2;
}

// 代理方法无需主动调用，在TableView加载时自动调用
#pragma mark - UITableViewDataSource
// 表格中section数量
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

// 表格中每个section的行数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.data.count;
    } else if (section ==1) {
        return self.section1Data.count;
    }
    return 0;
}

// 每一行的内容
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSLog(@"Index path section: %li row: %li", (long)indexPath.section, (long)indexPath.row);
    
    // 新建一个cell
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    
    if (indexPath.section == 0) {
        // 从section 0 data中获取一个字符串
        NSString *month = self.data[indexPath.row];
        
        // 在cell中间显示文字
        cell.textLabel.text = month;
    } else if (indexPath.section == 1) {
        // 从section 1 data中获取一个字符串
        NSString *day = self.section1Data[indexPath.row];
        
        // 在cell中间显示文字
        cell.textLabel.text = day;
    }
    
    // 返回UITableViewCell
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.section == 0) {
        // 从section 0 data中获取一个字符串
        NSString *month = self.data[indexPath.row];
        
        // 查看被选择的文字
        NSLog(@"User selected %@", month);
        
    } else if (indexPath.section == 1) {
        // 从section 1 data中获取一个字符串
        NSString *day = self.section1Data[indexPath.row];
        
        // 查看被选择的文字
        NSLog(@"User selected %@", day);
    }
    
    //取消对该行的选择
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

@end
