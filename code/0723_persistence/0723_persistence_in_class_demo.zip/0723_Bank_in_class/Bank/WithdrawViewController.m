//
//  WithdrawViewController.m
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "WithdrawViewController.h"

@interface WithdrawViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end

@implementation WithdrawViewController

// 用户输入了取款额度，按下Okay键
- (IBAction)didTapOkay:(id)sender {
    NSString *amount = self.textField.text;
    
    // 将字符转化为数字
    NSInteger integerAmount = [amount integerValue];
    
    // 调用取钱方法。如果取钱成功，该方法返回值为YES，返回WelcomeViewController
    if ([self.selectedAccount withdraw:integerAmount]) {
        // 返回WelcomeViewController
        [self performSegueWithIdentifier:@"didFinishWithdraw" sender:self];
    } else {
        
        // 如果取钱失败，显示余额不足警报
        UIAlertController *alert = [self withdrawFailedAlert];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

// 警报：余额不足，取钱失败
- (UIAlertController *) withdrawFailedAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"操作失败"
                                                                   message:@"余额不足"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction *action) {
                                                       self.textField.text = @"";
                                                    }];
    [alert addAction:action];
    return alert;
}

@end
