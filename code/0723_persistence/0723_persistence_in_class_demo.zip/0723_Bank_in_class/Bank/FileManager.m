//
//  FileManager.m
//  Bank
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "FileManager.h"
#import "Account.h"
@implementation FileManager
+ (NSURL *) XMLDataRecordsDirectory {
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // 在cache文件夹中添加一个XML文件夹
    NSURL *url = [NSURL URLWithString:@"XML/" relativeToURL:[FileManager applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

// cache文件夹
+ (NSURL *) applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}
@end
