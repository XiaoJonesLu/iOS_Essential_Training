//
//  FileManager.h
//  Bank
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FileManager : NSObject

/**
 返回XML文件夹的位置，注意是XML文件夹，
 不是xml文件本身。
 */
+ (NSURL *) XMLDataRecordsDirectory;

/**
 返回Cache文件夹的位置
 */
+ (NSURL *) applicationCacheDirectory;

@end
