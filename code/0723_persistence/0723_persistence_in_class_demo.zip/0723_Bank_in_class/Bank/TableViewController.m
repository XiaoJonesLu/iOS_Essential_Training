//
//  TableViewController.m
//  Bank
//
//  Created by Xiao on 7/22/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "TableViewController.h"

@interface TableViewController ()
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@end

@implementation TableViewController

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.allAccounts.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Account *account = self.allAccounts[indexPath.row];
    cell.textLabel.text = account.username;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"余额: %li", (long)account.balance];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        Account *account = self.allAccounts[indexPath.row];
        
        [self.allAccounts removeObject:account];
        
        [Account saveToFile:self.allAccounts];
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
        
    }
}

- (IBAction)didTapEdit:(id)sender {
    UIBarButtonItem *item = (UIBarButtonItem *) sender;
    if ([item.title isEqualToString: @"编辑"]) {
        item.title = @"完成";
        [self.tableView setEditing:YES animated:YES];
    } else if ([item.title isEqualToString:@"完成"]) {
        item.title = @"编辑";
        [self.tableView setEditing:NO animated:YES];
    }
}

@end
