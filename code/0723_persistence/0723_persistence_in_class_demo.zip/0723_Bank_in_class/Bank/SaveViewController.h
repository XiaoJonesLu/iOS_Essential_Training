//
//  SaveViewController.h
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Account.h"

@interface SaveViewController : UIViewController
@property (nonatomic, strong) Account *selectedAccount;
@end
