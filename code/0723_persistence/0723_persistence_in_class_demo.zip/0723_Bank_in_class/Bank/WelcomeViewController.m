//
//  WelcomeViewController.m
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "WelcomeViewController.h"
#import "WithdrawViewController.h"
#import "SaveViewController.h"

@interface WelcomeViewController ()
@property (weak, nonatomic) IBOutlet UILabel *welcomeLabel;
@property (weak, nonatomic) IBOutlet UILabel *balanceLabel;
@property (nonatomic, strong) NSNumberFormatter *formatter;
@end

@implementation WelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 测试self.selectedAccount是否被成功赋值
    NSLog(@"Welcome to WelcomeViewController");
    NSLog(@"Selected account is: %@", self.selectedAccount.username);
    
    // 显示用户名余额
    [self updateWelcomeMessage];
}

// 调用此方法来刷新用户名和余额
- (void) updateWelcomeMessage {
    // 更新用户名
    self.welcomeLabel.text=[NSString stringWithFormat:@"欢迎，%@", self.selectedAccount.username];
    
    // 更新余额
    NSNumber *balance = [NSNumber numberWithInteger:self.selectedAccount.balance];
    NSString *descriptiveBalance = [self.formatter stringFromNumber:balance];
    self.balanceLabel.text=[NSString stringWithFormat:@"您的余额: %@", descriptiveBalance];
}

/* 这个方程在执行segue(前往存钱/取钱界面)时被调用。如果segue的id是willSave，
 用户将要存钱，如果id是willWithdraw，用户将取钱。
 */
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    if ([segue.identifier isEqualToString:@"willSave"]) {
        // Get the new view controller using [segue destinationViewController].
        SaveViewController *dsvc = segue.destinationViewController;
        
        // Pass the selected object to the new view controller.
        dsvc.selectedAccount = self.selectedAccount;
    } else if ([segue.identifier isEqualToString:@"willWithdraw"]){
        // Get the new view controller using [segue destinationViewController].
        WithdrawViewController *dsvc = segue.destinationViewController;
        
        // Pass the selected object to the new view controller.
        dsvc.selectedAccount = self.selectedAccount;
    }
}

// 这个方程在unwindSegue执行以后被调用
- (IBAction) unwindToWelcomeViewController: (UIStoryboardSegue *) unwindSegue {
    // 保存所有账户数据
    [Account saveToFile:self.allAccounts];
    
    // 更新用户余额
    [self updateWelcomeMessage];
}

// formatter将数字转化为现金表现形式
- (NSNumberFormatter *)formatter {
    if (!_formatter) {
        _formatter = [[NSNumberFormatter alloc] init];
        _formatter.numberStyle = NSNumberFormatterCurrencyStyle;
    }
    return _formatter;
}

@end
