//
//  ViewController.m
//  Persistence
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 打出app根目录
    // 注：真机调试时，打出真机上的目录，Finder无法查看
    // 复制'/Users/....../Documents/'，在Finder中前往该目录
    NSLog(@"Documents Directory: %@", [[[NSFileManager defaultManager] URLsForDirectory:NSDocumentDirectory inDomains:NSUserDomainMask] lastObject]);
    
    // 通过XMLDataRecordsDirectory获得XML文件夹地址
    NSURL *XMLFolderDirectory = [self XMLDataRecordsDirectory];
    
    /* -----------------------------------
     以NSArray/NSMutableArray为例
      -----------------------------------*/
    // 建立一个array
    NSArray *arr = @[@"Account 1", @"Account 2"];
    
    // 创建了xml文件的地址
    NSURL *fileUrl = [NSURL URLWithString:@"array" relativeToURL: XMLFolderDirectory];
    
    // 将xml文件地址从NSURL转化成NSString
    NSString *stringPath = [fileUrl path];
    
    // 保存array文件到指定地址
    [arr writeToFile: stringPath atomically:YES];
    
    // Pseudo-code to save all Accounts instance:
    /*
     for every Account instance in the allAccounts
     Create a new dicionary
     Assign each property of the instance as a
     key-value pair into the dictionary
    
     Add the dictionary into a container array
     */
    
    // 读取文件时，可以以mutable或者immutable版本读取
    NSArray *readArray = [NSArray arrayWithContentsOfURL:fileUrl];
    NSMutableArray *readMutableArray = [NSMutableArray arrayWithContentsOfURL:fileUrl];
    
    for (NSDictionary *dict in readArray) {
        // 创建一个Account的实例
        // 将字典的username赋值给实例的username属性
        // 将字典的balance赋值给实例的balance属性
        
        // 添加实例到一个NSArray集合
    }
    
    /* -----------------------------------
     以NSDictionary/NSMutableDictionary为例
     -----------------------------------*/
    // 建立一个字典
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:@"Jeff" forKey:@"username"];
    [dict setObject:@"5th Ave" forKey:@"Address"];
    
    // 创建了xml文件的地址
    NSURL *dictUrl = [NSURL URLWithString:@"dict" relativeToURL:XMLFolderDirectory];
    
    // 将xml文件地址从NSURL转化成NSString
    NSString *dictStr = [dictUrl path];
    
    // 保存dict文件到指定地址
    [dict writeToFile: dictStr atomically:YES];
    
    // 读取文件时，可以以mutable或者immutable版本读取
    NSDictionary *readDict = [NSDictionary dictionaryWithContentsOfURL:dictUrl];
    NSMutableDictionary *readMutableDict = [NSMutableDictionary dictionaryWithContentsOfURL:dictUrl];
}

// cache文件夹
- (NSURL *)applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}

- (NSURL *) XMLDataRecordsDirectory{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // 在cache文件夹中添加了一个XML文件夹
    NSURL *url = [NSURL URLWithString:@"XML/" relativeToURL:[self applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

@end
