//
//  ViewController.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "LoginViewController.h"
#import "Account.h"
#import "WelcomeViewController.h"
#import "RegisterViewController.h"
#import "TableViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (nonatomic, strong) NSMutableArray *allAccounts;
@property (nonatomic, strong) Account *selectedAccount;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // App启动时，在最初的view controller加载的同时读取xml文件
    self.allAccounts = [Account readFromFile];
}

// Lazy loading
- (NSMutableArray *) allAccounts {
    if (!_allAccounts) {
        _allAccounts = [Account readFromFile];
    }
    return _allAccounts;
}

// 在每次视图出现时，将用户名和密码清除
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.nameField.text = @"";
    self.passwordField.text = @"";
}

- (IBAction)didTapNext:(id)sender {
    NSString *name = self.nameField.text;
    NSLog(@"User entered text: %@", name);
    
    /* 检查用户输入的名字是否与几何类型NSArray
     中任何账号相匹配，创建一个boolean，将其默认值
     设定为NO，在enumeration时，如果有匹配选项，将
     其赋值改为YES。
     */
    BOOL accountExist = NO;
    
    /* Objective-C Fast Enumeration: 对NSArray
     中每个元素进行相同的检查/操作。
     */
    for (Account *account in self.allAccounts) {
        // 查看集合中的每一个account
        NSLog(@"Checking account %@", account.username);
        
        // 如果用户名对上号，再检查密码是否正确
        if ([account.username isEqualToString:name]) {
            NSLog(@"The name the account is %@, balance %li", account.username, account.balance);
            
            // 将与用书信息相匹配的account赋值给self.selectedAccount
            self.selectedAccount = account;
            
            // 重新赋值boolean flag，账号存在
            accountExist = YES;
            
            // 如果密码正确，则登录成功
            if ([self.passwordField.text isEqualToString:account.password]) {
                
                // 将与用书信息相匹配的account赋值给self.selectedAccount
                self.selectedAccount = account;
                
                // 重新赋值boolean flag，账号存在
                accountExist = YES;
                
                // 账户存在，进入下一个view controller
                [self performSegueWithIdentifier:@"loginSuccess" sender:self];
                
            } else {
                // 如果密码错误，显示警报
                UIAlertController *alert = [self passwordIncorrectAlert];
                [self presentViewController:alert animated:YES completion:nil];
            }
            
            // 终止循环，无需继续检查后面的账号
            break;
        }
    }
    
    // 如果没有匹配的用户名，发出警报，用户不存在
    if (accountExist == NO) {
        NSLog(@"Account does not exist.");
        
        // 跳出对话框，显示“账号不存在”
        UIAlertController *alert = [self userNotExistAlert];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

// 即将执行segue，在进入下一view controller前，将必要的数据传给下一view controller
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    /* 如果segue的id是loginSuccess， 将WelcomeViewController的
     selectedAccount赋值为self.selectedAccount.
     */
    if ([segue.identifier isEqualToString:@"loginSuccess"]) {
        
        // 获取WelcomeViewController(segue的终点)。
        WelcomeViewController *welcomeViewController = segue.destinationViewController;
        
        /* 对WelcomeViewController.selectedAccount 赋值,
         注：此属性在WelcomeViewController.h中申明。
         */
        welcomeViewController.allAccounts = self.allAccounts;
        welcomeViewController.selectedAccount = self.selectedAccount;
        
    } else if ([segue.identifier isEqualToString:@"toRegister"]) {
        
        // 获取RegisterViewController
        RegisterViewController *registerViewController = segue.destinationViewController;
        
        // 将allAccounts传递给registerViewController
        registerViewController.allAccounts = self.allAccounts;
    } else if ([segue.identifier isEqualToString:@"allAccounts"]) {
        
        TableViewController *dsvc = segue.destinationViewController;
        
        dsvc.allAccounts = self.allAccounts;
    }
}

// 用户注册新用户后，返回登陆界面，所以这个方程在unwindSegue执行以后，
// 调用saveToFile:方法保存数据
- (IBAction) unwindToLoginViewController: (UIStoryboardSegue *) unwindSegue {
    [Account saveToFile: self.allAccounts];
}

// 警报：登录失败，密码错误
- (UIAlertController *) passwordIncorrectAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"操作失败"
                                                                   message:@"密码错误，请重试。"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction *action) {
                                                       self.passwordField.text = @"";
                                                   }];
    [alert addAction:action];
    return alert;
}

// 警报：登录失败，账号不存在
- (UIAlertController *) userNotExistAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"操作失败"
                                                                   message:@"账号不存在，请重新输入。"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction *action) {
                                                       self.nameField.text = @"";
                                                       self.passwordField.text = @"";
                                                       [self.nameField becomeFirstResponder];
                                                   }];
    [alert addAction:action];
    return alert;
}

@end
