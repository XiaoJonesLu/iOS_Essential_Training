//
//  Account.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "Account.h"
#import "FileManager.h"
@implementation Account

- (BOOL) withdraw: (NSInteger) amount {
    // 打印账户名及余额
    NSLog(@"The name of the account is %@", self.username);
    NSLog(@"The balance of the account is %li", self.balance);
    
    // 如果账户余额大于取钱数额，取钱成功
    if (self.balance >= amount) {
        self.balance = self.balance - amount;
        
        // 打印取款额度，以及取款后账户余额
        NSLog(@"User withdrew %li, remaining balance: %li", amount, self.balance);
        
        return YES;
    } else {
        
        // 余额不足，取款失败
        NSLog(@"Withdraw failed!");
        
        return NO;
    }
}

- (void) save: (NSInteger) amount {
    // 打印账户名及余额
    NSLog(@"The name of the account is %@", self.username);
    NSLog(@"The balance of the account is %li", self.balance);
    
    // 存款
    self.balance = self.balance + amount;
    
    // 打印存款余额，以及剩余余额
    NSLog(@"User saved %li, remaining balance: %li", amount, self.balance);
}

/* 目的：是将xml文件中的dicionaries转化一个个
 Account. 装进一个Array.
 */
+ (NSMutableArray *) readFromFile {
    // 通过XMLDataRecordsDirectory获得XML文件夹地址
    NSURL *folderPath = [FileManager XMLDataRecordsDirectory];
    
    // 创建了xml文件的地址
    NSURL *filePath = [NSURL URLWithString:@"Account" relativeToURL:folderPath];
    
    // 使用NSArray读取文件
    NSArray *readFile = [NSArray arrayWithContentsOfURL: filePath];
    
    // 检查读取的文件内容
    NSLog(@"File read from disk: %@", readFile);
    
    // 创建一个array，用于储存随后将创建的Account实例
    NSMutableArray *container = [NSMutableArray new];
    
    for (NSDictionary *dict in readFile) {
        // 创建一个Account的实例
        Account *account = [Account new];
        
        // 将字典的username赋值给实例的username属性
        account.username = [dict objectForKey:@"username"];
        
        // 将字典的password赋值给实例的password属性
        account.password = [dict objectForKey:@"password"];
        
        // 从字典读出balance (NSNumber)
        NSNumber *balnce = [dict objectForKey:@"balance"];
        
        // 将字典的balance赋值给实例的balance属性
        account.balance = balnce.integerValue;
        
        // 添加实例到一个NSArray
        [container addObject:account];
    }
    
    // 返回array，读取完毕。
    return container;
}

// 把所有的accounts存到硬盘上
+ (void) saveToFile: (NSMutableArray*) array {
    /* ------------------------------------
     将所有Account实例转化为NSDictionary保存在一个container
     array中，再将array存储在硬盘上。
     ------------------------------------ */
    
    // 通过XMLDataRecordsDirectory获得XML文件夹地址
    NSURL *XMLFolderDirectory = [FileManager XMLDataRecordsDirectory];
    
    // 创建了xml文件的地址
    NSURL *dictUrl = [NSURL URLWithString:@"Account" relativeToURL:XMLFolderDirectory];
    
    // 创建一个array, 装载dictionaries
    NSMutableArray *container = [NSMutableArray new];
    
    // 通过for loop循环结构将Account实例转化成dictionary
    for (Account *account in array) {
        
        // 打印account信息，方便调试所用
        NSLog(@"Account to save: %@ balance:%li", account.username, account.balance);
        
        // 创建一个新的dicionary
        NSMutableDictionary *dict = [NSMutableDictionary new];
        
        // Assign each property of the instance as a
        // key-value pair into the dictionary
        [dict setObject:account.username forKey:@"username"];
        
        [dict setObject:account.password forKey:@"password"];
        
        // Change nsinteger into a NSNumber object
        NSNumber *number = [NSNumber numberWithInteger:account.balance];
        
        // Save the NSNumber into the dicitonary
        [dict setObject: number forKey:@"balance"];
        
        // Add the dictionary into a container array
        [container addObject:dict];
    }
    
    // 查看container，此时应装载了若干dictionaries
    NSLog(@"Container: %@", container);
    
    // 将xml文件地址从NSURL转化成NSString
    NSString *dictStr = [dictUrl path];
    
    // 调用- (BOOL)writeToFile:(NSString *)path atomically:(BOOL)flag
    // 方法保存container文件到指定地址，覆盖原文件
    [container writeToFile: dictStr atomically:YES];
}

@end
