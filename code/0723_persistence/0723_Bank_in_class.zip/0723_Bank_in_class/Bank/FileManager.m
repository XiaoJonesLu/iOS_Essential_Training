//
//  FileManager.m
//  Bank
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "FileManager.h"
#import "Account.h"
@implementation FileManager

+ (NSURL *) XMLDataRecordsDirectory {
    // 获取NSFileManager的一个实例，通过此实例我们调用文件管理的方法，如创建/删除文件及文件夹等
    NSFileManager *fileManager = [NSFileManager defaultManager];
    
    // 获取cache文件夹地址
    NSURL *cache = [FileManager applicationCacheDirectory];
    
    // 以cache文件夹为参照，在其内部“拟定”一个XML文件夹，此文件夹暂时未被创建，相当于一个
    // 随机猜想的，但不知是否存在的网站
    NSURL *url = [NSURL URLWithString:@"XML/" relativeToURL:cache];
    
    // 在if statement中，我们用- (BOOL)fileExistsAtPath:(NSString *)path 方法
    // 检验上述url是否指向一个真实存在的文件夹(XML文件夹)，如果不存在，则调用
    // - (BOOL)createDirectoryAtPath... 方法创建XML文件夹
    
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    
    // 返回XML文件夹地址
    return url;
}



// 通过此方法，返回cache文件夹地址
+ (NSURL *) applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}
@end
