//
//  ViewController.m
//  TableViewPractice
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *firstSectionData;
@property (nonatomic, strong) NSMutableArray *secondSectionData;
@property (nonatomic, strong) NSMutableArray *thirdSectionData;
@end

@implementation ViewController

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.firstSectionData.count;
    } else if (section == 1) {
        return self.secondSectionData.count;
    } else if (section == 2) {
        return self.thirdSectionData.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    if (section == 0) {
        cell.textLabel.text = self.firstSectionData[row];
    } else if (section == 1) {
        cell.textLabel.text = self.secondSectionData[row];
    } else if (section == 2) {
        cell.textLabel.text = self.thirdSectionData[row];
    }
    return cell;
}

#pragma mark - UITableViewDegate
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    // editingStyle有多种，在这里我们写删除方法
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        // 第一步：首先删除数据本身，再更新视图
        // 创建两个整数，代表被选的row和section
        NSInteger section = indexPath.section;
        NSInteger row = indexPath.row;
        
        // 申明一个字符型
        NSString *title;
        if (section == 0) {
            // 从firstSectionData中获取被选择的数据
            title = self.firstSectionData[row];
            
            // 方法一：直接从NSMutableArray删除
            [self.firstSectionData removeObject:title];
            
            // 方法二：或者根据坐标index来删除
            // [self.firstSectionData removeObjectAtIndex:row];
            
        } else if (section == 1) {
            // 从secondSectionData中获取被选择的数据
            title = self.secondSectionData[row];
            
            // 方法一：直接从NSMutableArray删除
            [self.secondSectionData removeObject:title];
            
            // 方法二：或者根据坐标index来删除
            // [self.secondSectionData removeObjectAtIndex:row];
        } else if (section == 2) {
            // 从thirdSectionData中获取被选择的数据
            title = self.thirdSectionData[row];
            
            // 方法一：直接从NSMutableArray删除
            [self.thirdSectionData removeObject:title];
            
            // 方法二：或者根据坐标index来删除
            // [self.thirdSectionData removeObjectAtIndex:row];
        }
        // 检查是否删除了正确的数据
        NSLog(@"User tires to delete %@", title);
        
        // 第二步：删除视图上的数据（更新屏幕上的显示）
        [tableView deleteRowsAtIndexPaths:@[indexPath]
                         withRowAnimation:UITableViewRowAnimationFade];
    }
    
    // 结束TableView编辑状态
    [self.tableView setEditing:NO];
}

#pragma mark - IBAction
- (IBAction)didTapEdit:(id)sender {
    // 将TableView设置成编辑状态
    [self.tableView setEditing:YES];
}

#pragma mark - Data
- (NSMutableArray *)firstSectionData {
    if (!_firstSectionData) {
        _firstSectionData = [@[@"Account",
                              @"NSString",
                              @"NSDate",
                              @"NSArray",
                              @"NSMutableArray",
                              @"NSDictionary",
                              @"NSMutableDictionary"] mutableCopy];
    }
    return _firstSectionData;
}

- (NSMutableArray *)secondSectionData {
    if (!_secondSectionData) {
        _secondSectionData = [@[@"NSInteger",
                               @"int",
                               @"long",
                               @"double"
                               ] mutableCopy];
        
    }
    return _secondSectionData;
}

- (NSMutableArray *)thirdSectionData {
    if (!_thirdSectionData) {
        _thirdSectionData = [@[@"UILabel",
                              @"UIButton",
                              @"UITextField",
                              @"UITableView"] mutableCopy];
    }
    return _thirdSectionData;
}

@end
