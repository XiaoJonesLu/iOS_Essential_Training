//
//  ViewController.m
//  TableViewPractice
//
//  Created by Xiao on 7/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, strong) NSArray *firstSectionData;
@property (nonatomic, strong) NSArray *secondSectionData;
@property (nonatomic, strong) NSArray *thirdSectionData;
@end

@implementation ViewController

#pragma mark - UITableViewDataSource
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 3;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    if (section == 0) {
        return self.firstSectionData.count;
    } else if (section == 1) {
        return self.secondSectionData.count;
    } else if (section == 2) {
        return self.thirdSectionData.count;
    }
    return 0;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    if (section == 0) {
        cell.textLabel.text = self.firstSectionData[row];
    } else if (section == 1) {
        cell.textLabel.text = self.secondSectionData[row];
    } else if (section == 2) {
        cell.textLabel.text = self.thirdSectionData[row];
    }
    return cell;
}

#pragma mark - Data
- (NSArray *)firstSectionData {
    if (!_firstSectionData) {
        _firstSectionData = @[@"Account",
                              @"NSString",
                              @"NSDate",
                              @"NSArray",
                              @"NSMutableArray",
                              @"NSDictionary",
                              @"NSMutableDictionary"];
    }
    return _firstSectionData;
}

- (NSArray *)secondSectionData {
    if (!_secondSectionData) {
        _secondSectionData = @[@"NSInteger",
                               @"int",
                               @"long",
                               @"double"
                               ];
        
    }
    return _secondSectionData;
}

- (NSArray *)thirdSectionData {
    if (!_thirdSectionData) {
        _thirdSectionData = @[@"UILabel",
                              @"UIButton",
                              @"UITextField",
                              @"UITableView"];
    }
    return _thirdSectionData;
}

@end
