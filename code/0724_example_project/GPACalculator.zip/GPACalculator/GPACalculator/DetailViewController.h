//
//  DetailViewController.h
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Course.h"

@protocol CourseEditDelegate <NSObject>
- (void) didAddCourse: (Course*) course;
- (void) didUpdateCourse: (Course*) course;
@end

@interface DetailViewController : UIViewController <UITableViewDataSource, UITabBarDelegate>
@property (weak, nonatomic) id <CourseEditDelegate>delegate;
@property (nonatomic, strong) Course *selectedCourse;
@end
