//
//  ViewController.m
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "CoursesViewController.h"

@interface CoursesViewController ()
@property (weak, nonatomic) IBOutlet UILabel *gpaLabel;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *coursesArray;
@property (nonatomic, strong) Course *selectedCourse;
@end

@implementation CoursesViewController

- (void)viewWillAppear:(BOOL)animated {
    [Course logXMLFilePath];
    [self configureGPA];
}

#pragma mark - UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.coursesArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    CourseCell *cell = [tableView dequeueReusableCellWithIdentifier:@"CourseCell"];
    Course *course = self.coursesArray[indexPath.row];
    cell.nameLabel.text = course.name;
    cell.gradeLabel.text = course.grade;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.coursesArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        [Course save:self.coursesArray];
    }
    [self reloadData];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Course *course = self.coursesArray[indexPath.row];
    self.selectedCourse = course;
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self performSegueWithIdentifier:@"toEditCourse" sender:self];
}

#pragma mark - CourseEditDelegate
- (void)didUpdateCourse:(Course *)course {
    [self.coursesArray removeObject:self.selectedCourse];
    [self.coursesArray addObject:course];
    [Course save:self.coursesArray];
    [self reloadData];
}

- (void)didAddCourse:(Course *)course {
    [self.coursesArray addObject:course];
    [Course save:self.coursesArray];
    [self reloadData];
}

#pragma mark - Utilities
- (NSMutableArray *)coursesArray {
    if (!_coursesArray) {
        _coursesArray = [Course read];
    }
    return _coursesArray;
}

- (void) configureGPA {
    self.gpaLabel.text = [NSString stringWithFormat:@"%.2f", [Course GPA].floatValue];
}

- (void) reloadData {
    self.coursesArray = nil;
    [self.tableView reloadData];
    [self configureGPA];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    DetailViewController *dsvc = segue.destinationViewController;
    dsvc.delegate = self;
    if ([segue.identifier isEqualToString:@"toEditCourse"]) {
        dsvc.selectedCourse = self.selectedCourse;
        dsvc.title = @"Edit Course";
    }
}

- (IBAction)unwindtoTableView:(UIStoryboardSegue *)unwindSegue{
    [self reloadData];
}

@end
