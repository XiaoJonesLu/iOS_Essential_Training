//
//  ViewController.h
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Course.h"
#import "CourseCell.h"
#import "DetailViewController.h"

@interface CoursesViewController : UIViewController <UITabBarDelegate, UITableViewDataSource, CourseEditDelegate>


@end

