//
//  DetailViewController.m
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "DetailViewController.h"
#import "TextFieldCell.h"

@interface DetailViewController ()
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (nonatomic, assign) TextFieldCell *nameCell;
@property (nonatomic, assign) TextFieldCell *gradeCell;
@property (nonatomic, assign) TextFieldCell *creditCell;
@end

@implementation DetailViewController

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TextFieldCell"];
    if (indexPath.row == 0) {
        if (self.selectedCourse) {
            cell.textField.text = self.selectedCourse.name;
        }
        cell.titleLabel.text = @"Title";
    } else if (indexPath.row == 1) {
        if (self.selectedCourse) {
            cell.textField.text = self.selectedCourse.grade;
        }
        cell.titleLabel.text = @"Grade";
        cell.textField.keyboardType = UIKeyboardTypeAlphabet;
    } else if (indexPath.row == 2) {
        if (self.selectedCourse) {
            cell.textField.text = [NSString stringWithFormat:@"%@", self.selectedCourse.credit];
        }
        cell.titleLabel.text = @"Credit";
        cell.textField.keyboardType = UIKeyboardTypeNumberPad;
    }
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    return cell;
}

#pragma mark UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFieldCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textField becomeFirstResponder];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - Utilities
- (TextFieldCell *)nameCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

- (TextFieldCell *)gradeCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

- (TextFieldCell *)creditCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:2 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

#pragma mark IBAction
- (IBAction)didTapSave:(id)sender {
    Course *course = [[Course alloc] init];
    course.name = self.nameCell.textField.text;
    course.grade = self.gradeCell.textField.text;
    course.credit = [NSNumber numberWithFloat:self.creditCell.textField.text.floatValue];
    if (self.selectedCourse) {
        [self.delegate didUpdateCourse:course];
    } else {
        [self.delegate didAddCourse:course];
    }
    [self performSegueWithIdentifier:@"unwindtoTableView" sender:self];
}

@end
