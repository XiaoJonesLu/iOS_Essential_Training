//
//  Course.m
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.

#import "Course.h"

@implementation Course
- (id) init {
    if (self = [super init]) {
    }
    return self;
}

- (instancetype)initWithDict:(NSDictionary *)dict {
    if(self==[super init]) {
        _name = [dict valueForKey:@"name"];
        _credit = [dict valueForKey:@"credit"];
        _grade = [dict valueForKey:@"grade"];
    }
    return self;
}

- (NSMutableDictionary*) dictionaryRepresentation {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:self.name forKey:@"name"];
    [dict setValue:self.credit forKey:@"credit"];
    [dict setValue:self.grade forKey:@"grade"];
    return dict;
}

#pragma mark - Utilities
- (float) numGrade {
    NSDictionary *conversion = @{
                                 @"A" : @4,     @"A-": @3.7,
                                 @"B+": @3.3,   @"B" : @3,      @"B-": @2.7,
                                 @"C+": @2.3,   @"C" : @2.0,    @"C-": @1.7,
                                 @"D+": @1.3,   @"D" : @1,      @"D-": @0.7,
                                 @"F" : @0
                                 };
    NSNumber *scaled = [conversion objectForKey:self.grade];
    return scaled.floatValue;
}

+ (NSNumber *)GPA {
    NSArray *arr = [Course read];
    NSInteger creditSum = 0;
    float scoreTimesCreditSum = 0;
    for (Course *course in arr) {
        creditSum += course.credit.integerValue;
        float numGrade = [course numGrade];
        scoreTimesCreditSum += course.credit.integerValue * numGrade;
    }
    float GPA = 0;
    if (creditSum != 0) GPA = scoreTimesCreditSum/creditSum;
    return [NSNumber numberWithFloat:GPA];
}

#pragma mark - File Management
+ (void) logXMLFilePath {
    NSURL *fileURL = [NSURL URLWithString:@"Course" relativeToURL:[self XMLDataRecordsDirectory]];
    NSLog(@"%@", [fileURL path]);
}

+ (NSURL *)applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}

+ (void) save:(NSMutableArray* ) courseArr {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (Course *course in courseArr) {
        [array addObject: [course dictionaryRepresentation]];
    }
    NSURL *fileURL = [NSURL URLWithString:@"Course" relativeToURL:[self XMLDataRecordsDirectory]];
    [array writeToFile:[fileURL path] atomically:YES];
}

+ (NSMutableArray *)read {
    NSURL *fileURL = [NSURL URLWithString:@"Course" relativeToURL:[self XMLDataRecordsDirectory]];
    NSArray *array = [NSMutableArray arrayWithContentsOfURL:fileURL];
    NSMutableArray *datesArray = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in array) {
        Course *item = [[Course alloc] initWithDict:dict];
        [datesArray addObject: item];
    }
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"name" ascending:NO];
    [datesArray sortUsingDescriptors:@[sort]];
    NSLog(@"%@", datesArray);
    return datesArray;
}

+ (NSURL *)XMLDataRecordsDirectory{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *url = [NSURL URLWithString:@"XMLData/" relativeToURL:[Course applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

@end
