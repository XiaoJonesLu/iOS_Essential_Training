//
//  Course.h
//  GPACalculator
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Course : NSObject

@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *credit;
@property (nonatomic, strong) NSString *grade;

+ (void) logXMLFilePath;
- (float) numGrade;
+ (NSMutableArray *) read;
+ (void) save:(NSMutableArray* ) courseArr;
+ (NSNumber*) GPA;

@end
