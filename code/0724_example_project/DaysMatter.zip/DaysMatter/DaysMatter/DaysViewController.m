//
//  ViewController.m
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "DaysViewController.h"

@interface DaysViewController ()
@property (nonatomic, strong) NSMutableArray *datesArray;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@property (nonatomic, strong) NSDateFormatter *formatter;
@property (nonatomic, strong) Date *selectedBirthday;
@end

@implementation DaysViewController

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
    [self.tableView reloadData];
}
#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.datesArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Date *date = self.datesArray[indexPath.row];
    NSDateComponents *comps = [[NSCalendar currentCalendar] components:NSCalendarUnitDay fromDate:[NSDate date] toDate:date.date options:0];
    if (comps.day < 0) {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"过去%li天", -comps.day];
        cell.textLabel.textColor = [UIColor grayColor];
        cell.detailTextLabel.textColor = [UIColor grayColor];
    } else if (comps.day == 0) {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"今天"];
        cell.textLabel.font = [UIFont boldSystemFontOfSize:18];
        cell.detailTextLabel.font = [UIFont boldSystemFontOfSize:18];
    } else {
        cell.detailTextLabel.text = [NSString stringWithFormat:@"%li天", comps.day];
    }
    
    cell.textLabel.text = date.name;
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.datesArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        [Date save:self.datesArray];
    }
}

#pragma mark UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Date *date = self.datesArray[indexPath.row];
    self.selectedBirthday = date;
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self performSegueWithIdentifier:@"toUpdateDate" sender:self];
}

#pragma mark - DaysMatterDelegate
- (void)didAddDate:(Date *)newDate {
    [self.datesArray addObject:newDate];
    [Date save:self.datesArray];
    [self reloadData];
}

-(void)didUpdateDate:(Date *)newDate {
    [self.datesArray removeObject:self.selectedBirthday];
    [self.datesArray addObject:newDate];
    [Date save:self.datesArray];
    [self reloadData];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
    DayDetailViewController *dsvc = segue.destinationViewController;
    dsvc.delegate = self;
    if ([segue.identifier isEqualToString:@"toUpdateDate"]) {
        dsvc.selectedBirthday = self.selectedBirthday;
        dsvc.title = @"Edit Birthday";
    }
}

- (IBAction)unwindtoTableView:(UIStoryboardSegue *)unwindSegue{
    [self reloadData];
}

#pragma mark - Utilities
- (IBAction)toAddDate:(id)sender {
    [self performSegueWithIdentifier:@"toAddDate" sender:self];
}

- (NSMutableArray *)datesArray {
    if (!_datesArray) {
        _datesArray = [Date read];
    }
    return _datesArray;
}

- (NSDateFormatter *)formatter {
    if (!_formatter) {
        _formatter = [[NSDateFormatter alloc] init];
        _formatter.dateFormat = @"yyyy/MM/dd";
    }
    return _formatter;
}

- (void) reloadData {
    self.datesArray = nil;
    [self.tableView reloadData];
}

@end
