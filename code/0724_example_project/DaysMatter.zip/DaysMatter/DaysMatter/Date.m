//
//  Date.m
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "Date.h"

@implementation Date

#pragma mark - Instance Methods
- (id) init {
    if (self = [super init]) {
        self.date = [NSDate date];
    }
    return self;
}

- (instancetype)initWithDict:(NSDictionary *)dict {
    if(self==[super init]) {
        _date = [dict valueForKey:@"date"];
        _detail = [dict valueForKey:@"detail"];
        _name = [dict valueForKey:@"name"];
    }
    return self;
}

- (NSMutableDictionary*) dictionaryRepresentation {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:self.date forKey:@"date"];
    [dict setValue:self.detail forKey:@"detail"];
    [dict setValue:self.name forKey:@"name"];
    return dict;
}

#pragma mark - Class Methods
+ (void) logXMLFilePath {
    NSURL *fileURL = [NSURL URLWithString:@"DaysMatter" relativeToURL:[self XMLDataRecordsDirectory]];
    NSLog(@"%@", [fileURL path]);
}

+ (NSURL *)applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}

+ (void) save:(NSMutableArray* )datesArray {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (Date *date in datesArray) {
        [array addObject: [date dictionaryRepresentation]];
    }
    NSURL *fileURL = [NSURL URLWithString:@"DaysMatter" relativeToURL:[self XMLDataRecordsDirectory]];
    [array writeToFile:[fileURL path] atomically:YES];
}

+ (NSMutableArray *)read {
    NSURL *fileURL = [NSURL URLWithString:@"DaysMatter" relativeToURL:[self XMLDataRecordsDirectory]];
    NSArray *array = [NSMutableArray arrayWithContentsOfURL:fileURL];
    NSMutableArray *datesArray = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in array) {
        Date *item = [[Date alloc] initWithDict:dict];
        [datesArray addObject: item];
    }
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"date" ascending:NO];
    [datesArray sortUsingDescriptors:@[sort]];
    NSLog(@"%@", datesArray);
    return datesArray;
}

+ (NSURL *)XMLDataRecordsDirectory{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *url = [NSURL URLWithString:@"XMLRecords/" relativeToURL:[Date applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

@end
