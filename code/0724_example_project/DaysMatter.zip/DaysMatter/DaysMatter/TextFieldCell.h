//
//  TextFieldCell.h
//  DaysMatter
//
//  Created by Xiao on 7/24/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TextFieldCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end
