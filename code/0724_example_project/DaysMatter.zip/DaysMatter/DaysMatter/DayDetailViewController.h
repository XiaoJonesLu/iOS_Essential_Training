//
//  DayDetailViewController.h
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Date.h"

@protocol DaysMatterDelegate <NSObject>
- (void) didAddDate: (Date*) newDate;
- (void) didUpdateDate: (Date*) newDate;
@end

@interface DayDetailViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, UITextViewDelegate>
@property (weak, nonatomic) id <DaysMatterDelegate>delegate;
@property (nonatomic, strong) Date *selectedBirthday;
@end
