//
//  Date.h
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Date : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSDate *date;
@property (nonatomic, strong) NSString *detail;

+ (void) logXMLFilePath;
- (instancetype)initWithDict:(NSDictionary *)dict;
+ (NSMutableArray *)read;
+ (void) save:(NSMutableArray* )datesArray;

@end
