//
//  ViewController.h
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Date.h"
#import "DayDetailViewController.h"

@interface DaysViewController : UIViewController <UITableViewDelegate, UITableViewDataSource, DaysMatterDelegate>


@end

