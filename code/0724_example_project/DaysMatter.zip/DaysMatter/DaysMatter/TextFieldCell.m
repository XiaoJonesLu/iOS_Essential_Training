//
//  TextFieldCell.m
//  DaysMatter
//
//  Created by Xiao on 7/24/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "TextFieldCell.h"

@implementation TextFieldCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
