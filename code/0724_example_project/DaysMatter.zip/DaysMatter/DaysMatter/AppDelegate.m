//
//  AppDelegate.m
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "AppDelegate.h"
#import "Date.h"
@interface AppDelegate ()

@end

@implementation AppDelegate

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    [Date logXMLFilePath];
    return YES;
}

@end
