//
//  DayDetailViewController.m
//  DaysMatter
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "DayDetailViewController.h"
#import "TextFieldCell.h"
#import "TextViewCell.h"
#import "PickerViewCell.h"

@interface DayDetailViewController ()

@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) UITextField *nameTextField;
@property (weak, nonatomic) UITextView *detailTextView;
@property (weak, nonatomic) UIDatePicker *datePicker;
@property (weak, nonatomic) TextFieldCell *textFieldCell;
@property (weak, nonatomic) TextViewCell *textViewCell;
@property (weak, nonatomic) PickerViewCell *pickerViewCell;
@end

@implementation DayDetailViewController

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        TextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TextFieldCell"];
        if (self.selectedBirthday) {
            cell.textField.text = self.selectedBirthday.name;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    } else if (indexPath.row == 1) {
        TextViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TextViewCell"];
        if (self.selectedBirthday) {
            cell.textView.text = self.selectedBirthday.detail;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    } else if (indexPath.row == 2) {
        PickerViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PickerViewCell"];
        if (self.selectedBirthday) {
            cell.datePicker.date = self.selectedBirthday.date;
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }
    return nil;
}

#pragma mark UITableViewDelegate
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 15;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    if (indexPath.row == 0) {
        return 44;
    } else if (indexPath.row == 1) {
        return 60;
    } else if (indexPath.row == 2) {
        return 160;
    }
    return 0;
}

#pragma mark - UITextViewDelegate
- (void)textViewDidBeginEditing:(UITextView *)textView {
    if ([textView.text isEqualToString:@"Event description"]) {
        textView.text = @"";
    }
}

#pragma mark - Utilities
- (IBAction)didTapSave:(id)sender {
    Date *newDate = [[Date alloc] init];
    newDate.date = self.datePicker.date;
    newDate.name = self.nameTextField.text;
    newDate.detail = self.detailTextView.text;
    if (self.selectedBirthday) {
        [self.delegate didUpdateDate:newDate];
    } else {
        [self.delegate didAddDate:newDate];
    }
    [self performSegueWithIdentifier:@"unwindtoTableView" sender:self];
}

- (UITextField *)nameTextField {
    return self.textFieldCell.textField;
}

- (UITextView *)detailTextView {
    return self.textViewCell.textView;
}

- (UIDatePicker *)datePicker {
    return self.pickerViewCell.datePicker;
}

- (TextFieldCell *)textFieldCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

- (TextViewCell *)textViewCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

- (PickerViewCell *)pickerViewCell {
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:2 inSection:0];
    return [self.tableView cellForRowAtIndexPath:indexPath];
}

@end
