//
//  ViewController.m
//  Notes
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "NotesViewController.h"

@interface NotesViewController ()
@property (nonatomic, strong) NSMutableArray *notesArray;
@property (nonatomic, strong) Note *selectedNote;
@property (nonatomic, strong) NSDateFormatter *formatter;
@end

@implementation NotesViewController

- (void)viewDidLoad {
    [Note logXMLFilePath];
}

#pragma mark - UITableView
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.notesArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    Note *note = self.notesArray[indexPath.row];
    cell.textLabel.text = note.noteText;
    cell.detailTextLabel.text = [self.formatter stringFromDate:note.lastModified];
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.notesArray removeObjectAtIndex:indexPath.row];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationLeft];
        [Note save:self.notesArray];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    Note *note = self.notesArray[indexPath.row];
    self.selectedNote = note;
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self performSegueWithIdentifier:@"toUpdateNote" sender:self];
}

#pragma mark - Navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    EditorViewController *dsvc = segue.destinationViewController;
    dsvc.delegate = self;
    if ([segue.identifier isEqualToString:@"toUpdateNote"]) {
        dsvc.title = @"Edit Note";
        dsvc.selectedNote = self.selectedNote;
    }
}

- (IBAction)unwindtoTableView:(UIStoryboardSegue *)unwindSegue{
    [self reloadData];
}

#pragma mark - NoteEditDelegate
- (void)didAddNote:(Note *)note {
    [self.notesArray addObject:note];
    [Note save:self.notesArray];
    [self reloadData];
}

- (void)didUpdateNote:(Note *)note {
    [self.notesArray removeObject: self.selectedNote];
    [self.notesArray addObject:note];
    [Note save:self.notesArray];
    [self reloadData];
}

#pragma mark - Utilities
- (NSMutableArray *)notesArray {
    if (!_notesArray) {
        _notesArray = [Note read];
    }
    return _notesArray;
}

- (NSDateFormatter *)formatter {
    if (!_formatter) {
        _formatter = [[NSDateFormatter alloc] init];
        _formatter.dateFormat = @"MM/dd";
    }
    return _formatter;
}

- (void) reloadData{
    self.notesArray = nil;
    [self.tableView reloadData];
}

@end
