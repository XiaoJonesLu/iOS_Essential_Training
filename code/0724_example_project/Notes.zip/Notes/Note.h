//
//  Note.h
//  Notes
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Note : NSObject
@property (nonatomic, strong) NSString *noteText;
@property (nonatomic, strong) NSDate *lastModified;

- (instancetype)initWithDict:(NSDictionary *)dict;
+ (void) logXMLFilePath;
+ (NSMutableArray *)read;
+ (void) save:(NSMutableArray* )notesArray;
@end
