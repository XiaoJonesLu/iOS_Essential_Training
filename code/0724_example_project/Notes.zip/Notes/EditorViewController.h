//
//  NoteViewController.h
//  Notes
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NotesViewController.h"
#import "Note.h"
@protocol NoteEditDelegate <NSObject>
- (void) didAddNote: (Note*) note;
- (void) didUpdateNote: (Note*) note;
@end
@interface EditorViewController : UIViewController
@property (weak, nonatomic) id <NoteEditDelegate>delegate;
@property (nonatomic, strong) Note *selectedNote;
@end
