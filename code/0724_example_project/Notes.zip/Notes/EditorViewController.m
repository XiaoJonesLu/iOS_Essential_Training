//
//  NoteViewController.m
//  Notes
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "EditorViewController.h"

@interface EditorViewController ()
@property (nonatomic, weak) IBOutlet UITextView *noteTextView;
@end

@implementation EditorViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    if (self.selectedNote) {
        self.noteTextView.text = self.selectedNote.noteText;
    }
}

- (IBAction)didTapSave:(id)sender {
    Note *note = [[Note alloc] init];
    note.noteText = self.noteTextView.text;
    note.lastModified = [NSDate date];
    if (self.selectedNote) {
        [self.delegate didUpdateNote:note];
    } else {
        [self.delegate didAddNote:note];
    }
    [self performSegueWithIdentifier:@"unwindtoTableView" sender:self];
}

@end
