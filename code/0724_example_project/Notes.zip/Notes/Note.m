//
//  Note.m
//  Notes
//
//  Created by Xiao on 7/19/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "Note.h"

@implementation Note

#pragma mark - Instance Methods
- (id) init {
    if (self = [super init]) {
        self.lastModified = [NSDate date];
    }
    return self;
}

- (instancetype)initWithDict:(NSDictionary *)dict {
    if(self==[super init]) {
        _noteText = [dict valueForKey:@"noteText"];
        _lastModified = [dict valueForKey:@"lastModified"];
    }
    return self;
}

- (NSMutableDictionary*) dictionaryRepresentation {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:self.noteText forKey:@"noteText"];
    [dict setValue:self.lastModified forKey:@"lastModified"];
    return dict;
}

#pragma mark - Class Methods
+ (void) logXMLFilePath {
    NSURL *fileURL = [NSURL URLWithString:@"Notes" relativeToURL:[self XMLDataRecordsDirectory]];
    NSLog(@"%@", [fileURL path]);
}

+ (NSURL *)applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}

+ (void) save:(NSMutableArray* )notesArray {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (Note *note in notesArray) {
        [array addObject: [note dictionaryRepresentation]];
    }
    NSURL *fileURL = [NSURL URLWithString:@"Notes" relativeToURL:[self XMLDataRecordsDirectory]];
    [array writeToFile:[fileURL path] atomically:YES];
}

+ (NSMutableArray *)read {
    NSURL *fileURL = [NSURL URLWithString:@"Notes" relativeToURL:[self XMLDataRecordsDirectory]];
    NSArray *array = [NSMutableArray arrayWithContentsOfURL:fileURL];
    NSMutableArray *notesArray = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in array) {
        Note *item = [[Note alloc] initWithDict:dict];
        [notesArray addObject: item];
    }
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"lastModified" ascending:NO];
    [notesArray sortUsingDescriptors:@[sort]];
    NSLog(@"%@", notesArray);
    return notesArray;
}

+ (NSURL *)XMLDataRecordsDirectory{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *url = [NSURL URLWithString:@"XMLData/" relativeToURL:[Note applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

@end
