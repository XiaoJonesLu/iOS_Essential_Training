//
//  ItemDetailVC.m
//  Grocery
//
//  Created by Xiao on 3/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ItemDetailVC.h"
#import "TextFieldCell.h"
#import "Macros.h"

@interface ItemDetailVC ()
@property (nonatomic, weak) TextFieldCell *item;
@property (nonatomic, weak) TextFieldCell *count;
@property (nonatomic, weak) TextFieldCell *price;
@property (nonatomic, weak) IBOutlet UITableView *tableView;
@end

@implementation ItemDetailVC

- (void)viewDidAppear:(BOOL)animated {
    [super viewDidAppear:YES];
    [self.item.textfield becomeFirstResponder];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 3;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFieldCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    switch (indexPath.row) {
        case 0:
            cell.textfield.placeholder =ITEM_CELL_PLACEHOLDER;
            cell.label.text = ITEM_CELL_TITLE;
            if (self.groceryItem) cell.textfield.text = self.groceryItem.name;
            break;
        case 1:
            cell.textfield.placeholder = COUNT_CELL_PLACEHOLDER;
            cell.textfield.keyboardType = UIKeyboardTypeNumberPad;
            cell.label.text = COUNT_CELL_TITLE;
            if (self.groceryItem)
                cell.textfield.text = [self.groceryItem.count stringValue];
            else
                cell.textfield.text = @"1";
            break;
        case 2:
            cell.textfield.placeholder = PRICE_CELL_PLACEHOLDER;
            cell.textfield.keyboardType = UIKeyboardTypeDecimalPad;
            cell.label.text = PRICE_CELL_TITLE;
            if (self.groceryItem) cell.textfield.text = [self.groceryItem.price stringValue];
            break;
        default:
            break;
    }
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    TextFieldCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    [cell.textfield becomeFirstResponder];
    if (indexPath.row == 1 && !self.groceryItem && [cell.textfield.text isEqualToString:@"1"]) {
        cell.textfield.text = @"";
    }
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

#pragma mark - UITextFieldDelegate
- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if ([textField isEqual:self.count.textfield] && [textField.text isEqualToString:@"1"] && !self.groceryItem) {
        textField.text = @"";
    }
}
- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [self didTapSave:nil];
    return YES;
}

#pragma mark - Utilities
- (TextFieldCell *)item {
    return [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:0]];
}

- (TextFieldCell *)count {
    return [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:1 inSection:0]];
}

-(TextFieldCell *)price {
    return [self.tableView cellForRowAtIndexPath:[NSIndexPath indexPathForRow:2 inSection:0]];
}

#pragma mark IBAction
- (IBAction)didTapSave:(id)sender {
    GroceryItem *itemToSave;
    if (self.groceryItem) {
        itemToSave = self.groceryItem;
    } else {
        itemToSave = [[GroceryItem alloc] init];
        itemToSave.time = [NSDate date];
    }
    itemToSave.name = self.item.textfield.text;
    if ([self.item.textfield.text isEqualToString:@""]) {
        [self presentViewController:[self noItemNameAlert] animated:YES completion:nil];
    } else if (![self.price.textfield.text doubleValue] || ![self.count.textfield.text integerValue]) {
        [self presentViewController:[self invalidNumberAlert] animated:YES completion:nil];
    } else {
        itemToSave.price = [NSNumber numberWithDouble:[self.price.textfield.text doubleValue]];
        itemToSave.count = [NSNumber numberWithInteger:[self.count.textfield.text integerValue]];
        self.groceryItem = itemToSave;
        [self performSegueWithIdentifier:UNWIND_TO_GROCERY_LIST_SEGUE sender:self];
    }
}

#pragma mark Alert
- (UIAlertController *) invalidNumberAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:INVALID_NUM_ALERT_TITLE
                                                                   message:INVALID_NUM_ALERT_MESSAGE
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *act = [UIAlertAction actionWithTitle:ALERT_DISMISS style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        if (![self.count.textfield.text integerValue]) {
            [self.count.textfield becomeFirstResponder];
        } else if (![self.price.textfield.text doubleValue]) {
            [self.price.textfield becomeFirstResponder];
        }
    }];
    [alert addAction:act];
    return alert;
}

- (UIAlertController *) noItemNameAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:NO_ITEM_NAME_ALERT_TITLE
                                                                   message:NO_ITEM_NAME_ALERT_MESSAGE
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *act = [UIAlertAction actionWithTitle:ALERT_DISMISS style:UIAlertActionStyleDefault handler:^(UIAlertAction *action){
        [self.item.textfield becomeFirstResponder];
    }];
    [alert addAction:act];
    return alert;
}

@end
