//
//  NavigationVC.h
//  Grocery
//
//  Created by Xiao on 7/5/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NavigationVC : UINavigationController

@end
