//
//  ViewController.m
//  Grocery
//
//  Created by Xiao on 3/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "Macros.h"
#import "GroveryListVC.h"
#import "ItemDetailVC.h"
#import "GroceryCell.h"

@interface GroveryListVC ()
@property (weak, nonatomic) IBOutlet UITableView *groceryListTableView;
@property (nonatomic, strong) NSMutableArray *groceryList;
@property (nonatomic, strong) GroceryItem *selectedGroceryItem;
@property (nonatomic, strong) NSDateFormatter *formatter;
@end

@implementation GroveryListVC
- (void)viewDidLoad {
    [super viewDidLoad];
    [GroceryManager logXMLFilePath];
}

#pragma mark - UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.groceryList.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    GroceryCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    GroceryItem *item = self.groceryList[indexPath.row];
    cell.titleLabel.text = item.name;
    NSString *locKey = LOCALIZED_NUM_ITEMS_TIMES_PRICE_EQUAL_NET;
    cell.detailLabel.text = [NSString stringWithFormat:locKey, item.count, item.price.floatValue, item.totalPrice.floatValue];
    if (item.time) cell.dateLabel.text = [self.formatter stringFromDate:item.time];
    return cell;
}

#pragma mark - UITableViewDelegate
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    self.selectedGroceryItem = [self.groceryList objectAtIndex:indexPath.row];
    [self performSegueWithIdentifier:TO_UPDATE_ITEM_SEGUE sender:self];
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        [self.groceryList removeObjectAtIndex:indexPath.row];
        [self.groceryListTableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        [GroceryManager saveGroceryList:self.groceryList];
    }
}

#pragma mark - UpdateGroceryDelegate
- (void)didUpdateGroceryItem:(GroceryItem *)groceryItem {
    [self.groceryList replaceObjectAtIndex:[self.groceryList indexOfObject:self.selectedGroceryItem] withObject:groceryItem];
    [self.groceryListTableView reloadData];
    [GroceryManager saveGroceryList:self.groceryList];
}

- (void)dismissUpdateItemVC {
    [self.groceryListTableView deselectRowAtIndexPath:[self.groceryListTableView indexPathForSelectedRow] animated:YES];
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Utilities
- (NSMutableArray*) groceryList {
    if (_groceryList == nil) {
        _groceryList = [GroceryManager read];
        return _groceryList;
    }
    return _groceryList;
}

- (NSDateFormatter *)formatter {
    if (_formatter) {
        return _formatter;
    }
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    NSString *format = [NSDateFormatter dateFormatFromTemplate:@"MM/dd" options:0 locale:[NSLocale currentLocale]];
    formatter.dateFormat = format;
    _formatter = formatter;
    return _formatter;
}

- (IBAction)didTapAdd:(id)sender {
    [self performSegueWithIdentifier:TO_ADD_ITEM_SEGUE sender:self];
}

#pragma mark - Navigation
- (IBAction)unwindtoGroceryList:(UIStoryboardSegue *)unwindSegue{
    if ([unwindSegue.identifier isEqualToString:UNWIND_TO_GROCERY_LIST_SEGUE]) {
        ItemDetailVC *svc = (ItemDetailVC*) unwindSegue.sourceViewController;
        GroceryItem *newItem = svc.groceryItem;
        NSLog(@"New item is added %@, number: %@, price for each: %@", newItem.name, newItem.count, newItem.price);
        if (self.selectedGroceryItem) [self.groceryList removeObject:self.selectedGroceryItem];
        [self.groceryList insertObject:newItem atIndex:0];
        NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"time" ascending:NO];
        [self.groceryList sortUsingDescriptors:@[sort]];
    }
    [self.groceryListTableView reloadData];
    [GroceryManager saveGroceryList:self.groceryList];
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    ItemDetailVC *dsvc = segue.destinationViewController;
    if ([segue.identifier isEqualToString:TO_UPDATE_ITEM_SEGUE]) {
        dsvc.groceryItem = self.selectedGroceryItem;
    } else if ([segue.identifier isEqualToString:TO_ADD_ITEM_SEGUE]) {
        dsvc.groceryItem = nil;
        self.selectedGroceryItem = nil;
    }
}

@end
