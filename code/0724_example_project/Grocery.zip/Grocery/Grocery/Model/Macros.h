//
//  Macros.h
//  Grocery
//
//  Created by Xiao on 7/8/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#ifndef Macros_h
#define Macros_h

#define ITEM_CELL_TITLE NSLocalizedString(@"ITEM_CELL_TITLE", nil)
#define COUNT_CELL_TITLE NSLocalizedString(@"COUNT_CELL_TITLE", nil)
#define PRICE_CELL_TITLE NSLocalizedString(@"PRICE_CELL_TITLE", nil)

#define ITEM_CELL_PLACEHOLDER NSLocalizedString(@"ITEM_CELL_PLACEHOLDER", nil)
#define COUNT_CELL_PLACEHOLDER NSLocalizedString(@"COUNT_CELL_PLACEHOLDER", nil)
#define PRICE_CELL_PLACEHOLDER NSLocalizedString(@"PRICE_CELL_PLACEHOLDER", nil)

#define INVALID_NUM_ALERT_TITLE NSLocalizedString(@"INVALID_NUM_ALERT_TITLE", nil)
#define INVALID_NUM_ALERT_MESSAGE NSLocalizedString(@"INVALID_NUM_ALERT_MESSAGE", nil)
#define ALERT_DISMISS NSLocalizedString(@"ALERT_DISMISS", nil)

#define NO_ITEM_NAME_ALERT_TITLE NSLocalizedString(@"NO_ITEM_NAME_ALERT_TITLE", nil)
#define NO_ITEM_NAME_ALERT_MESSAGE NSLocalizedString(@"NO_ITEM_NAME_ALERT_MESSAGE", nil)
#define NO_ITEM_NAME_ALERT_ACT NSLocalizedString(@"NO_ITEM_NAME_ALERT_ACT", nil)

#define TO_ADD_ITEM_SEGUE @"toAddItem"
#define TO_UPDATE_ITEM_SEGUE @"toUpdateItem"
#define UNWIND_TO_GROCERY_LIST_SEGUE @"unwindtoGroceryList"

#define LOCALIZED_NUM_ITEMS_TIMES_PRICE_EQUAL_NET NSLocalizedString(@"NUM_ITEMS_TIMES_PRICE_EQUAL_NET", nil)
#endif /* Macros_h */
