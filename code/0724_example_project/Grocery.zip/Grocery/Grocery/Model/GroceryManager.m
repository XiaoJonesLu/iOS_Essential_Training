//
//  GroceryManager.m
//  Grocery
//
//  Created by Xiao on 3/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "GroceryManager.h"

@implementation GroceryManager

+ (void) logXMLFilePath {
    NSURL *fileURL = [NSURL URLWithString:@"Grocery" relativeToURL:[GroceryManager XMLDataRecordsDirectory]];
    NSLog(@"%@", [fileURL path]);
}

+ (NSURL *)applicationCacheDirectory {
    return [[[NSFileManager defaultManager] URLsForDirectory:NSCachesDirectory inDomains:NSUserDomainMask] lastObject];
}

+ (void) saveGroceryList:(NSMutableArray* )groceryList {
    NSMutableArray *array = [[NSMutableArray alloc] init];
    for (GroceryItem *item in groceryList) {
        [array addObject: [item dictionaryRepresentation]];
    }
    NSURL *fileURL = [NSURL URLWithString:@"Grocery" relativeToURL:[GroceryManager XMLDataRecordsDirectory]];
    [array writeToFile:[fileURL path] atomically:YES];
}

+ (NSMutableArray *)read {
    NSURL *fileURL = [NSURL URLWithString:@"Grocery" relativeToURL:[GroceryManager XMLDataRecordsDirectory]];
    NSArray *array = [NSMutableArray arrayWithContentsOfURL:fileURL];
    NSMutableArray *groceryArray = [[NSMutableArray alloc] init];
    for (NSDictionary *dict in array) {
        GroceryItem *item = [[GroceryItem alloc] initWithDict:dict];
        [groceryArray addObject: item];
    }
    NSSortDescriptor *sort = [NSSortDescriptor sortDescriptorWithKey:@"time" ascending:NO];
    [groceryArray sortUsingDescriptors:@[sort]];
    NSLog(@"%@", groceryArray);
    return groceryArray;
}

+ (NSURL *)XMLDataRecordsDirectory{
    NSFileManager *fileManager = [NSFileManager defaultManager];
    NSURL *url = [NSURL URLWithString:@"XMLData/" relativeToURL:[GroceryManager applicationCacheDirectory]];
    NSError *error = nil;
    if (![fileManager fileExistsAtPath:[url path]]) {
        [fileManager createDirectoryAtPath:[url path] withIntermediateDirectories:YES attributes:nil error:&error];
    }
    return url;
}

@end
