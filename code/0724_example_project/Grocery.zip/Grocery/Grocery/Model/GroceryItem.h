//
//  GroceryItem.h
//  Grocery
//
//  Created by Xiao on 3/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GroceryItem : NSObject
@property (nonatomic, strong) NSString *name;
@property (nonatomic, strong) NSNumber *count;
@property (nonatomic, strong) NSNumber *price;
@property (nonatomic, strong) NSNumber *totalPrice;
@property (nonatomic, strong) NSDate *time;

- (NSMutableDictionary*) dictionaryRepresentation;
- (instancetype)initWithDict:(NSDictionary*)dict;
@end
