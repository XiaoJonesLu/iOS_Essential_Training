//
//  GroceryItem.m
//  Grocery
//
//  Created by Xiao on 3/23/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "GroceryItem.h"

@implementation GroceryItem
- (id) init {
    if (self = [super init]) {
        self.count = [NSNumber numberWithInt:0];
        self.price = [NSNumber numberWithInt:0];
    }
    return self;
}

- (instancetype)initWithDict:(NSDictionary *)dict {
    if(self==[super init]) {
        _name = [dict valueForKey:@"name"];
        _count = [dict valueForKey:@"count"];
        _price = [dict valueForKey:@"price"];
        _time = [dict valueForKey:@"time"];
    }
    return self;
}

- (NSNumber*) totalPrice {
    double totalPrice = self.count.integerValue * self.price.doubleValue;
    return [NSNumber numberWithDouble:totalPrice];
}

- (NSMutableDictionary*) dictionaryRepresentation {
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setValue:self.name forKey:@"name"];
    [dict setValue:self.count forKey:@"count"];
    [dict setValue:self.price forKey:@"price"];
    [dict setValue:self.time forKey:@"time"];
    return dict;
}

@end
