//
//  ViewController.m
//  Grader
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic, weak) IBOutlet UITextField *scoreTextField;
@property (nonatomic, weak) IBOutlet UILabel *gradeLabel;
@property (weak, nonatomic) IBOutlet UIButton *button;
@end

@implementation ViewController

- (IBAction)didTapGradingButton:(id)sender {
    // 查看button上面的文字，如果文字为Get Grade，则计算letter grade
    if ([self.button.titleLabel.text isEqualToString:@"Get Grade"]) {
        
        // 获取用户输入的文字，将其转化为浮点
        float score = [self.scoreTextField.text floatValue];
        
        // 如果分数在0~100之间，
        if (score >= 0 && score <= 100) {
            
            // 调用gradeForScore: 代入score(浮点), 将返回值(NSString)显示在gradeLabel上
            self.gradeLabel.text = [self gradeForScore:score];
            
            // 将按钮文字修改为Clear
            [self.button setTitle: @"Clear" forState:UIControlStateNormal];
            
            // 收起键盘，结束编辑
            [self.scoreTextField resignFirstResponder];
        } else {
            // 如果分数不在1~100之间，显示alert(对话框)
            UIAlertController *alert = [self invalidScoreAlert];
            [self presentViewController:alert animated:YES completion:nil];
        }
        
    } else if ([self.button.titleLabel.text isEqualToString:@"Clear"]) {
        // 如果按钮文字为Clear，清楚label和textfield上的内容
        [self clear];
        
        // 将按钮文字改回Get Grade
        [self.button setTitle: @"Get Grade" forState:UIControlStateNormal];
        
        // 激活键盘，开始编辑
        [self.scoreTextField becomeFirstResponder];
    }
}

// 此方程将label和textfield清零
- (void) clear {
    self.gradeLabel.text = @"";
    self.scoreTextField.text = @"";
}

// 返回一个UIAlertController
- (UIAlertController *) invalidScoreAlert {
    // 创建一个UIAlertController， 将其标题设置为Invalid Score, 
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"Invalid Score"
                                                                   message:@"Please enter a score between 0~100."
                                                            preferredStyle:UIAlertControllerStyleAlert];
    
    // 创建一个按钮，按钮的标题为Okay，
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"Okay"
                                                     style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
                                                         [self clear];
                                                     }];
    
    // 将按钮添加到alert
    [alert addAction:action];
    
    // 返回UIAlertController
    return alert;
}

// 方程接受一个浮点型做为参数，根据浮点判断字母成绩，返回字母成绩
- (NSString *) gradeForScore: (float) score {
    if (score >= 92) {
        NSLog(@"Studnet receives numeric score: %f letter grade: A", score);
        return @"A";
    } else if (score >= 87) {
        NSLog(@"Studnet receives numeric score: %f letter grade: A-", score);
        return @"A-";
    }  else if (score >= 82) {
        NSLog(@"Studnet receives numeric score: %f letter grade: B+", score);
        return @"B+";
    } else if (score >= 76) {
        NSLog(@"Studnet receives numeric score: %f letter grade: B", score);
        return @"B";
    } else if (score >= 68) {
        NSLog(@"Studnet receives numeric score: %f letter grade: B-", score);
        return @"B-";
    } else if (score >= 60) {
        NSLog(@"Studnet receives numeric score: %f letter grade: C+", score);
        return @"C+";
    }
    NSLog(@"Studnet receives numeric score: %f letter grade: F", score);
    return @"F";
}

@end
