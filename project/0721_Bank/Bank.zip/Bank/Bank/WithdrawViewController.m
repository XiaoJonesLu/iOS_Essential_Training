//
//  WithdrawViewController.m
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "WithdrawViewController.h"

@interface WithdrawViewController ()
@property (weak, nonatomic) IBOutlet UITextField *textField;
@end

@implementation WithdrawViewController

// 用户输入了取款额度，按下Okay键
- (IBAction)didTapOkay:(id)sender {
    NSString *amount = self.textField.text;
    
    // 将字符转化为数字
    NSInteger integerAmount = [amount integerValue];
    
    // 调用取钱方法
    [self.selectedAccount withdraw:integerAmount];
    
    // 返回WelcomeViewController
    [self performSegueWithIdentifier:@"didFinishWithdraw" sender:self];
}

@end
