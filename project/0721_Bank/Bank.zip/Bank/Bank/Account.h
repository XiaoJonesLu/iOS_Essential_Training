//
//  Account.h
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Account : NSObject

// 账户姓名
@property (nonatomic, strong) NSString *username;

// 账户余额
@property (nonatomic, assign) NSInteger balance;

// 取款方程，参数：取款额
- (void) withdraw: (NSInteger) amount;

// 存款方程，参数：存款额
- (void) save: (NSInteger) amount;

@end
