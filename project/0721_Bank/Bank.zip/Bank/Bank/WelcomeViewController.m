//
//  WelcomeViewController.m
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "WelcomeViewController.h"
#import "WithdrawViewController.h"

@interface WelcomeViewController ()
@property (weak, nonatomic) IBOutlet UILabel *welcomeLabel;
@property (weak, nonatomic) IBOutlet UILabel *balanceLabel;
@end

@implementation WelcomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 测试self.selectedAccount是否被成功赋值
    NSLog(@"Welcome to WelcomeViewController");
    NSLog(@"Selected account is: %@", self.selectedAccount.username);
    
    // 显示用户名余额
    [self updateWelcomeMessage];
}

- (void) updateWelcomeMessage {
    // 更新用户名
    self.welcomeLabel.text=[NSString stringWithFormat:@"Welcome, %@", self.selectedAccount.username];
    
    // 更新余额
    self.balanceLabel.text=[NSString stringWithFormat:@"Balance: %li", self.selectedAccount.balance];
}

// 这个方程在执行segue(前往存钱/取钱界面)时被调用
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    // Get the new view controller using [segue destinationViewController].
    WithdrawViewController *dsvc = segue.destinationViewController;
    
    // Pass the selected object to the new view controller.
    dsvc.selectedAccount = self.selectedAccount;
}

// 这个方程在unwindSegue执行以后被调用
- (IBAction) unwindToWelcomeViewController: (UIStoryboardSegue *) unwindSegue {
    NSLog(@"User finished withdrawing money.");
    
    // 更新用户余额
    [self updateWelcomeMessage];
}

@end
