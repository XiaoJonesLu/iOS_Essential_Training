//
//  WelcomeViewController.h
//  Bank
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Account.h"

@interface WelcomeViewController : UIViewController
@property (nonatomic, strong) Account *selectedAccount;
@end
