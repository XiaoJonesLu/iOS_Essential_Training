//
//  ViewController.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "LoginViewController.h"
#import "Account.h"
#import "WelcomeViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (nonatomic, strong) NSArray *allAccounts;
@property (nonatomic, strong) Account *selectedAccount;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /* --------------------------------------
     Method 1: declare, alloc, and init
     in three separate steps.
     --------------------------------------*/
    // 先申明变量
    Account *myAccount;
    
    // allocate memory for the instance
    myAccount = [Account alloc];
    
    // initialize the instance
    myAccount = [myAccount init];
    
    myAccount.username = @"Me";
    myAccount.balance = 10000;
    
    // Me取款11000, 取款失败，余额不足
    [myAccount withdraw:11000];
    
    // Me取款1000
    [myAccount save:1000];
    
    // Me取款11000，取款成功
    [myAccount withdraw:11000];
    
    /* ------------------------------------
     Method 2: declare, alloc, and init
     in one single step.
     --------------------------------------*/
    // alloc and init in a single line
    Account *hisAccount = [[Account alloc] init];
    hisAccount.username = @"Trump";
    hisAccount.balance = 99999999;
    
    [hisAccount withdraw:500];
    
    /* ------------------------------------
     Use 'new' method to instantiate in a single step
     --------------------------------------*/
    Account *herAccount = [Account new];
    herAccount.username = @"May";
    herAccount.balance = 50;
    
    // Mary取款1000
    [herAccount withdraw:1000];
    
    self.allAccounts = @[myAccount, herAccount, hisAccount];
}

- (IBAction)didTapNext:(id)sender {
    NSString *name = self.nameField.text;
    NSLog(@"User entered text: %@", name);
    
    /* 检查用户输入的名字是否与几何类型NSArray
     中任何账号相匹配，创建一个boolean，将其默认值
     设定为NO，在enumeration时，如果有匹配选项，将
     其赋值改为YES。
     */
    BOOL accountExist = NO;
    
    /* Objective-C Fast Enumeration: 对NSArray
     中每个元素进行相同的检查/操作。
     */
    for (Account *account in self.allAccounts) {
        NSLog(@"Checking account %@", account.username);
        
        // 查看集合中的每一个account
        if ([account.username isEqualToString:name]) {
            NSLog(@"The name the account is %@, balance %li", account.username, account.balance);
            
            // 将与用书信息相匹配的account赋值给self.selectedAccount
            self.selectedAccount = account;
            
            // 重新赋值boolean flag，账号存在
            accountExist = YES;
            
            // 账户存在，进入下一个view controller
            [self performSegueWithIdentifier:@"loginSuccess" sender:self];
            
            // 终止循环，无需继续检查后面的账号
            break;
        }
    }
    
    if (accountExist == NO) {
        NSLog(@"Account does not exist.");
        // 跳出对话框，显示“账号不存在”
    }
}

- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    /* 如果segue的id是loginSuccess， 将WelcomeViewController的
     selectedAccount赋值为self.selectedAccount.
     */
    if ([segue.identifier isEqualToString:@"loginSuccess"]) {
        
        // 获取WelcomeViewController(segue的终点)。
        WelcomeViewController *welcomeViewController = segue.destinationViewController;
        
        /* 对WelcomeViewController.selectedAccount 赋值,
         注：此属性在WelcomeViewController.h中申明。
         */
        welcomeViewController.selectedAccount = self.selectedAccount;
    }
}

@end
