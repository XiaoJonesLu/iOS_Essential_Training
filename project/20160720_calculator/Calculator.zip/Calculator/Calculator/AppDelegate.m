//
//  AppDelegate.m
//  Calculator
//
//  Created by Xiao on 7/18/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

@end
