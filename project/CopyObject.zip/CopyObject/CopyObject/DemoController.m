//
//  ViewController.m
//  CopyObject
//
//  Created by Xiao on 7/21/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "DemoController.h"
#import "Account.h"
@interface DemoController ()

@end

@implementation DemoController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    // Create an integer
    NSInteger a = 5;
    
    // Assign the integer to a second integer
    NSInteger b = a;
    
    // Change the second integer
    b = b - 2;
    
    // Check the first and the second integer
    NSLog(@"a = %li, b = %li", (long)a, (long)b);
    
    /* Summary ---------------------------------
     The two integers are different. So changing
     one integer does not affect the other.
     ------------------------------------------*/
    
    
    
    
    
    
    // Create a mutable array
    NSMutableArray *arrayA = [@[@"July", @"August"] mutableCopy];
    
    // Assign the mutable array to a second mutable array
    NSMutableArray *arrayB = arrayA;
    
    // Remove one object from the second array
    [arrayB removeObject:@"August"];
    
    // Check how many element(s) in each array
    NSLog(@"arrayA has %li element(s), arrayB has %li element(s).", (unsigned long)arrayA.count, (unsigned long)arrayB.count);
    
    /* Summary ---------------------------------
     The two arrays are the name. Changing one a
     rray affects the other. Two variables point
     to the same memory location.
     ------------------------------------------*/
    
    
    
    
    
    
    // Create a mutable array
    NSMutableArray *arrayC = [@[@"July", @"August"] mutableCopy];
    
    // Assign the COPY of the mutable array to a second mutable array
    NSMutableArray *arrayD = [arrayC mutableCopy];
    
    // Remove one object from the second array
    [arrayD removeObject:@"August"];
    
    // Check how many element(s) in each array
    NSLog(@"arrayC has %li element(s), arrayD has %li element(s).", (unsigned long)arrayC.count, (unsigned long)arrayD.count);
    
    /* Summary ---------------------------------
     The two arrays are different. By using the
     mutableCopy method, a separate copy of the
     object is created. Changes to the copy doe
     s NOT affec the original one.
     ------------------------------------------*/
    
    
    
    
    
    
    Account *accountA = [[Account alloc] init];
    accountA.username = @"UserA";
    Account *accountB = accountA;
    accountB.username = @"UserB";
    NSLog(@"Account A: %@, Account B: %@", accountA.username, accountB.username);
    
    /* Summary ---------------------------------
     The two accounts are the same. Changing one
     account(account B) affects the other (accou
     nt A). Two variables point to the same memo
     ry location.
     ------------------------------------------*/

    
    
    
    
    
    Account *accountC = [[Account alloc] init];
    accountC.username = @"UserC";
    Account *accountD = [accountC mutableCopy];
    accountD.username = @"UserD";
    NSLog(@"Account C: %@, Account D: %@", accountC.username, accountD.username);
    
    /* Summary ---------------------------------
     The two accounts are different. By defining 
     and using the mutableCopy method, a separate
     copy of accountC is created. Changes to the
     copy (accountD) does NOT affec the original
     accountC.
     ------------------------------------------*/
}

@end
