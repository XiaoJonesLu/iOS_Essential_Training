//
//  ViewController.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "LoginViewController.h"
#import "Account.h"
#import "WelcomeViewController.h"
#import "RegisterViewController.h"

@interface LoginViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (nonatomic, strong) NSMutableArray *allAccounts;
@property (nonatomic, strong) Account *selectedAccount;
@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /* --------------------------------------
     Method 1: declare, alloc, and init
     in three separate steps.
     --------------------------------------*/
    // 先申明变量
    Account *myAccount;
    
    // allocate memory for the instance
    myAccount = [Account alloc];
    
    // initialize the instance
    myAccount = [myAccount init];
    
    myAccount.username = @"Me";
    myAccount.balance = 10000;
    
    /* ------------------------------------
     Method 2: declare, alloc, and init
     in one single step.
     --------------------------------------*/
    // alloc and init in a single line
    Account *hisAccount = [[Account alloc] init];
    hisAccount.username = @"Trump";
    hisAccount.balance = 99999999;
    
    /* ------------------------------------
     Method 3: Use 'new' method to instantiate in a single step
     --------------------------------------*/
    Account *herAccount = [Account new];
    herAccount.username = @"May";
    herAccount.balance = 50;
    
    // 赋值符号前后类型必须一致，将NSArray转成NSMutableArray再赋值给self.allAccount
    NSArray *array = @[myAccount, herAccount, hisAccount];
    
    NSMutableArray *mutableCopy = [array mutableCopy];
    
    self.allAccounts = mutableCopy;
    
    // 一步到位
    // self.allAccounts = [@[myAccount, herAccount, hisAccount] mutableCopy];
}

// 在每次视图出现时，将用户名和密码清除
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:YES];
    self.nameField.text = @"";
    self.passwordField.text = @"";
}

- (IBAction)didTapNext:(id)sender {
    NSString *name = self.nameField.text;
    NSLog(@"User entered text: %@", name);
    
    /* 检查用户输入的名字是否与几何类型NSArray
     中任何账号相匹配，创建一个boolean，将其默认值
     设定为NO，在enumeration时，如果有匹配选项，将
     其赋值改为YES。
     */
    BOOL accountExist = NO;
    
    /* Objective-C Fast Enumeration: 对NSArray
     中每个元素进行相同的检查/操作。
     */
    for (Account *account in self.allAccounts) {
        // 查看集合中的每一个account
        NSLog(@"Checking account %@", account.username);
        
        // 如果用户名对上号，再检查密码是否正确
        if ([account.username isEqualToString:name]) {
            NSLog(@"The name the account is %@, balance %li", account.username, (long)account.balance);
            
            // 将与用书信息相匹配的account赋值给self.selectedAccount
            self.selectedAccount = account;
            
            // 重新赋值boolean flag，账号存在
            accountExist = YES;
            
            // 账户存在，进入下一个view controller
            [self performSegueWithIdentifier:@"loginSuccess" sender:self];
            
            // 终止循环，无需继续检查后面的账号
            break;
        }
    }
    
    // 如果没有匹配的用户名，发出警报，用户不存在
    if (accountExist == NO) {
        NSLog(@"Account does not exist.");
        
        // 跳出对话框，显示“账号不存在”
        UIAlertController *alert = [self userNotExistAlert];
        [self presentViewController:alert animated:YES completion:nil];
    }
}

// 即将执行segue，在进入下一view controller前，将必要的数据传给下一view controller
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    
    /* 如果segue的id是loginSuccess， 将WelcomeViewController的
     selectedAccount赋值为self.selectedAccount.
     */
    if ([segue.identifier isEqualToString:@"loginSuccess"]) {
        
        // 获取WelcomeViewController(segue的终点)。
        WelcomeViewController *welcomeViewController = segue.destinationViewController;
        
        /* 对WelcomeViewController.selectedAccount 赋值,
         注：此属性在WelcomeViewController.h中申明。
         */
        welcomeViewController.selectedAccount = self.selectedAccount;
        
    } else if ([segue.identifier isEqualToString:@"toRegister"]) {
        
        // 获取RegisterViewController
        RegisterViewController *registerViewController = segue.destinationViewController;
        
        // 将allAccounts传递给registerViewController
        registerViewController.allAccounts = self.allAccounts;
    }
}

// 这个方程在unwindSegue执行以后被调用
- (IBAction) unwindToLoginViewController: (UIStoryboardSegue *) unwindSegue {
}

// 警报：登录失败，账号不存在
- (UIAlertController *) userNotExistAlert {
    UIAlertController *alert = [UIAlertController alertControllerWithTitle:@"操作失败"
                                                                   message:@"账号不存在，请重新输入。"
                                                            preferredStyle:UIAlertControllerStyleAlert];
    UIAlertAction *action = [UIAlertAction actionWithTitle:@"知道了"
                                                     style:UIAlertActionStyleDefault
                                                   handler:^(UIAlertAction *action) {
                                                       self.nameField.text = @"";
                                                       self.passwordField.text = @"";
                                                       [self.nameField becomeFirstResponder];
                                                   }];
    [alert addAction:action];
    return alert;
}

@end
