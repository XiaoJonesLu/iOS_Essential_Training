//
//  RegisterViewController.m
//  Bank
//
//  Created by Xiao on 7/22/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "RegisterViewController.h"
#import "Account.h"

@interface RegisterViewController ()
@property (weak, nonatomic) IBOutlet UITextField *usernameField;
@end

@implementation RegisterViewController

- (void)viewDidLoad {
    // 检查当前用户数量
    NSLog(@"All accounts: %@", self.allAccounts);
}

// 用户输入用户名和密码之后按下"注册"键
- (IBAction)didTapRegister:(id)sender {
    NSString *username = self.usernameField.text;
    
    // 新建实例(instance)
    Account *newAccount = [Account new];
    newAccount.username = username;
    
    // 将新建的账户添加到allAccounts中
    [self.allAccounts addObject:newAccount];
    
    // 检查添加是否成功
    NSLog(@"All accounts (after register): %@", self.allAccounts);
    
    // 返回登陆界面
    [self performSegueWithIdentifier:@"unwindToLogin" sender:self];
}

@end
