//
//  ViewController.m
//  Bank
//
//  Created by Xiao on 7/20/16.
//  Copyright © 2016 Xiao Lu. All rights reserved.
//

#import "ViewController.h"
#import "Account.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    /* --------------------------------------
     Method 1: declare, alloc, and init
     in three separate steps.
     --------------------------------------*/
    // 先申明变量
    Account *myAccount;
    
    // allocate memory for the instance
    myAccount = [Account alloc];
    
    // initialize the instance
    myAccount = [myAccount init];
    
    myAccount.username = @"Me";
    myAccount.balance = 10000;
    
    // Me取款11000, 取款失败，余额不足
    [myAccount withdraw:11000];
    
    // Me取款1000
    [myAccount save:1000];
    
    // Me取款11000，取款成功
    [myAccount withdraw:11000];
    
    /* ------------------------------------
     Method 2: declare, alloc, and init
     in one single step.
     --------------------------------------*/
    // alloc and init in a single line
    Account *hisAccount = [[Account alloc] init];
    hisAccount.username = @"Trump";
    hisAccount.balance = 99999999;
    
    [hisAccount withdraw:500];
    
    /* ------------------------------------
     Use 'new' method to instantiate in a single step 
     --------------------------------------*/
    Account *herAccount = [Account new];
    herAccount.username = @"May";
    herAccount.balance = 50;
    
    // Mary取款1000
    [herAccount withdraw:1000];
}

@end
